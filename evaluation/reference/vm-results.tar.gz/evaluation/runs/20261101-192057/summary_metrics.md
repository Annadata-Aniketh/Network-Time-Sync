# Time synchronization results

| Metric | Baseline Mode | SDN-Optimized Mode | Reduction (%) |
| --- | ---: | ---: | ---: |
| Mean RTT (ms) | 113.563 | 21.959 | +80.66% |
| P95 RTT (ms) | 200.188 | 29.515 | +85.26% |
| Mean Jitter (ms) | 7.760 | 3.532 | +54.48% |
| Mean Clock Error (ms) | 56.615 | 1.049 | +98.15% |
| P95 Clock Error (ms) | 117.586 | 2.604 | +97.79% |
| Convergence Time (s) | 4.504 | 1.504 | +66.62% |
| Failed samples (%) | 20.613 | 0.000 | +100.00% |

RTT and jitter use successful replies only. Clock error includes failed attempts.
Clock error is sampled immediately after correction, not continuously between requests.
Convergence requires three successive rounds with all clients at or below 2 ms.
N/A means unavailable or not confirmed. Positive reduction means a lower measured value.
Use controller logs and flow counters to verify rerouting; these plots do not establish when it happened.
