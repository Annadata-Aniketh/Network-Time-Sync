# Time synchronization results

| Metric | Baseline Mode | SDN-Optimized Mode | Reduction (%) |
| --- | ---: | ---: | ---: |
| Mean RTT (ms) | 104.701 | 21.992 | +79.00% |
| P95 RTT (ms) | 200.016 | 28.311 | +85.85% |
| Mean Jitter (ms) | 7.785 | 3.393 | +56.42% |
| Mean Clock Error (ms) | 53.329 | 1.048 | +98.03% |
| P95 Clock Error (ms) | 124.188 | 3.134 | +97.48% |
| Convergence Time (s) | 1.503 | 3.502 | -133.06% |
| Failed samples (%) | 23.380 | 0.000 | +100.00% |

RTT and jitter use successful replies only. Clock error includes failed attempts.
Clock error is sampled immediately after correction, not continuously between requests.
Convergence requires three successive rounds with all clients at or below 2 ms.
N/A means unavailable or not confirmed. Positive reduction means a lower measured value.
Use controller logs and flow counters to verify rerouting; these plots do not establish when it happened.
