# Time synchronization results

| Metric | Baseline Mode | SDN-Optimized Mode | Reduction (%) |
| --- | ---: | ---: | ---: |
| Mean RTT (ms) | 119.156 | 22.892 | +80.79% |
| P95 RTT (ms) | 211.386 | 31.691 | +85.01% |
| Mean Jitter (ms) | 6.196 | 3.851 | +37.84% |
| Mean Clock Error (ms) | 60.233 | 1.158 | +98.08% |
| P95 Clock Error (ms) | 128.302 | 3.424 | +97.33% |
| Convergence Time (s) | 1.503 | 3.502 | -133.05% |
| Failed samples (%) | 19.075 | 0.000 | +100.00% |

RTT and jitter use successful replies only. Clock error includes failed attempts.
Clock error is sampled immediately after correction, not continuously between requests.
Convergence requires three successive rounds with all clients at or below 2 ms.
N/A means unavailable or not confirmed. Positive reduction means a lower measured value.
Use controller logs and flow counters to verify rerouting; these plots do not establish when it happened.
