# Time synchronization results

| Metric | Baseline Mode | SDN-Optimized Mode | Reduction (%) |
| --- | ---: | ---: | ---: |
| Mean RTT (ms) | 121.607 | 22.259 | +81.70% |
| P95 RTT (ms) | 219.360 | 29.481 | +86.56% |
| Mean Jitter (ms) | 6.528 | 3.320 | +49.14% |
| Mean Clock Error (ms) | 60.927 | 1.110 | +98.18% |
| P95 Clock Error (ms) | 127.624 | 3.133 | +97.54% |
| Convergence Time (s) | 1.503 | 5.502 | -266.12% |
| Failed samples (%) | 20.506 | 0.000 | +100.00% |

RTT and jitter use successful replies only. Clock error includes failed attempts.
Clock error is sampled immediately after correction, not continuously between requests.
Convergence requires three successive rounds with all clients at or below 2 ms.
N/A means unavailable or not confirmed. Positive reduction means a lower measured value.
Use controller logs and flow counters to verify rerouting; these plots do not establish when it happened.
