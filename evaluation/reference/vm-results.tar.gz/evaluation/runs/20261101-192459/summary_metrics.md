# Time synchronization results

| Metric | Baseline Mode | SDN-Optimized Mode | Reduction (%) |
| --- | ---: | ---: | ---: |
| Mean RTT (ms) | 96.142 | 22.097 | +77.02% |
| P95 RTT (ms) | 196.668 | 28.305 | +85.61% |
| Mean Jitter (ms) | 8.441 | 3.171 | +62.44% |
| Mean Clock Error (ms) | 54.041 | 1.034 | +98.09% |
| P95 Clock Error (ms) | 139.642 | 2.977 | +97.87% |
| Convergence Time (s) | 8.006 | 3.502 | +56.26% |
| Failed samples (%) | 28.783 | 0.000 | +100.00% |

RTT and jitter use successful replies only. Clock error includes failed attempts.
Clock error is sampled immediately after correction, not continuously between requests.
Convergence requires three successive rounds with all clients at or below 2 ms.
N/A means unavailable or not confirmed. Positive reduction means a lower measured value.
Use controller logs and flow counters to verify rerouting; these plots do not establish when it happened.
