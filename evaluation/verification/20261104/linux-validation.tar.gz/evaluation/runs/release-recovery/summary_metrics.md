# Automatic recovery: PASS

- PASS: Sync requests used Path B under load
- PASS: Reroute rules removed from s1, s3, and s4
- PASS: Sync request counter increased on Path A after load stopped
- PASS: All three clients received replies during recovery
