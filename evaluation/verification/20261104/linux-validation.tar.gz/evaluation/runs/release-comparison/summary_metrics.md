# Time synchronization results

| Metric | Baseline Mode | SDN-Optimized Mode | Reduction (%) |
| --- | ---: | ---: | ---: |
| Mean RTT (ms) | 103.349 | 20.559 | +80.11% |
| P95 RTT (ms) | 210.027 | 32.113 | +84.71% |
| Mean Jitter (ms) | 4.939 | 2.847 | +42.34% |
| Mean Clock Error (ms) | 50.457 | 0.856 | +98.30% |
| P95 Clock Error (ms) | 115.103 | 2.257 | +98.04% |
| Convergence Time (s) | 1.502 | 1.502 | +0.02% |
| Failed samples (%) | 20.728 | 0.000 | +100.00% |

RTT and jitter use successful replies only. Clock error includes failed attempts.
Clock error is sampled immediately after correction, not continuously between requests.
Convergence requires three successive rounds with all clients at or below 2 ms.
N/A means unavailable or not confirmed. Positive reduction means a lower measured value.
Use controller logs and flow counters to verify rerouting; these plots do not establish when it happened.
